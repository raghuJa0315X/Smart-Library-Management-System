const API_URL = 'http://localhost:5000/api';

document.addEventListener('DOMContentLoaded', () => {
  initThemeToggle();
  initCounters();
  fetchProjects('All');
  initFilterTabs();
  initContactForm();
});

// Theme Switcher (Dark / Light Mode)
function initThemeToggle() {
  const toggleBtn = document.getElementById('theme-toggle');
  const icon = toggleBtn.querySelector('i');
  
  toggleBtn.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    icon.className = newTheme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
  });
}

// Animated Experience Numbers
function initCounters() {
  const statNums = document.querySelectorAll('.stat-num');
  statNums.forEach(stat => {
    const target = +stat.getAttribute('data-target');
    let count = 0;
    const speed = target / 30;
    
    const updateCount = () => {
      count += speed;
      if (count < target) {
        stat.innerText = Math.ceil(count) + (target === 99 ? '%' : '+');
        setTimeout(updateCount, 30);
      } else {
        stat.innerText = target + (target === 99 ? '%' : '+');
      }
    };
    updateCount();
  });
}

// Project Filtering
function initFilterTabs() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      fetchProjects(btn.getAttribute('data-filter'));
    });
  });
}

// Fetch Projects from Backend
async function fetchProjects(category) {
  const projectList = document.getElementById('project-list');
  projectList.innerHTML = '<p style="text-align:center; grid-column: 1/-1;">Loading projects...</p>';

  try {
    const response = await fetch(`${API_URL}/projects?category=${category}`);
    if (!response.ok) throw new Error('API fetch failed');
    const projects = await response.json();

    projectList.innerHTML = '';
    if (projects.length === 0) {
      projectList.innerHTML = '<p style="text-align:center; grid-column: 1/-1;">No projects found for this category.</p>';
      return;
    }

    projects.forEach(project => renderProjectCard(project, projectList));
  } catch (error) {
    console.error('Error:', error);
    renderFallbackProjects(projectList, category);
  }
}

// Render Single Project Card
function renderProjectCard(project, container) {
  const card = document.createElement('div');
  card.className = 'project-card';
  const techTags = project.technologies.map(t => `<span class="tag">${t}</span>`).join('');

  card.innerHTML = `
    <div>
      <div class="project-header">
        <h3 class="project-title">${project.title}</h3>
        <span class="views-count"><i class="fas fa-eye"></i> ${project.views || 0}</span>
      </div>
      <p class="project-desc">${project.description}</p>
    </div>
    <div>
      <div class="tags">${techTags}</div>
      <div class="links">
        ${project.githubLink ? `<a href="${project.githubLink}" target="_blank"><i class="fab fa-github"></i> Source</a>` : ''}
        ${project.liveDemoLink ? `<a href="${project.liveDemoLink}" target="_blank"><i class="fas fa-external-link-alt"></i> Live Demo</a>` : ''}
      </div>
    </div>
  `;
  container.appendChild(card);
}

// Client-Side Dynamic Contact Form Handler
function initContactForm() {
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    status.style.color = 'var(--accent)';
    status.innerText = 'Sending message...';

    const payload = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      message: document.getElementById('message').value
    };

    try {
      const response = await fetch(`${API_URL}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        status.style.color = '#22c55e';
        status.innerText = 'Message sent successfully!';
        form.reset();
      } else {
        throw new Error('Server error');
      }
    } catch (err) {
      status.style.color = '#ef4444';
      status.innerText = 'Message logged locally. Connect backend to save to database!';
    }
  });
}

// Local Fallback Projects when server is offline
function renderFallbackProjects(container, category) {
  const sampleProjects = [
    {
      title: "Microservices E-Commerce Core",
      category: "Full-Stack",
      description: "Scalable online store engine with Express.js APIs, MongoDB schema design, and seamless checkout integrations.",
      technologies: ["Node.js", "Express", "MongoDB", "Docker"],
      githubLink: "https://github.com",
      liveDemoLink: "https://example.com",
      views: 142
    },
    {
      title: "Real-time Analytics Dashboard",
      category: "Frontend",
      description: "Interactive data visualization dashboard featuring theme customization, WebSocket updates, and dark mode.",
      technologies: ["JavaScript", "Chart.js", "CSS3", "HTML5"],
      githubLink: "https://github.com",
      liveDemoLink: "https://example.com",
      views: 98
    },
    {
      title: "Authentication & Authorization Service",
      category: "Backend",
      description: "Secure JWT authentication microservice supporting OAuth2, session management, and rate limiting.",
      technologies: ["Node.js", "Express", "PostgreSQL", "JWT"],
      githubLink: "https://github.com",
      liveDemoLink: "https://example.com",
      views: 215
    }
  ];

  container.innerHTML = '';
  const filtered = category === 'All' ? sampleProjects : sampleProjects.filter(p => p.category === category);
  filtered.forEach(p => renderProjectCard(p, container));
}